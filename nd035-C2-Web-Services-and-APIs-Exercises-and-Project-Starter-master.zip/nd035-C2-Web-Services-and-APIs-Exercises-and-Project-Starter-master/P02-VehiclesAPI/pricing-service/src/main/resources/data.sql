INSERT INTO Price (vid, currency, price) VALUES (1, 'dollar', 5.20);
INSERT INTO Price (vid, currency, price) VALUES (2, 'dollar', 3.40);
INSERT INTO Price (vid, currency, price) VALUES (3, 'dollar', 2.20);
INSERT INTO Price (vid, currency, price) VALUES (4, 'dollar', 5.20);
INSERT INTO Price (vid, currency, price) VALUES (5, 'dollar', 1.20);
